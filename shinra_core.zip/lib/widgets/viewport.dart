﻿import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../models/rig.dart';
import '../services/animation_rig_sync.dart';

class ShinraViewport extends StatelessWidget {
  const ShinraViewport({super.key, required this.project, this.showBones = true, this.poseMode = false});
  final ProjectState project;
  final bool showBones;
  /// When true, dragging on the canvas moves/rotates the selected bone
  /// (project.poseTool: 'move'/'rotate'/'scale') instead of panning the
  /// camera — lets someone actually pose a hand/foot/head before capturing
  /// a keyframe, as an alternative to typing numbers in the Inspector.
  /// Free pan/zoom is disabled while posing so the drag isn't ambiguous.
  final bool poseMode;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
        builder: (_, c) => InteractiveViewer(
          minScale: .35,
          maxScale: 3.5,
          panEnabled: !poseMode,
          scaleEnabled: !poseMode,
          child: Center(
            child: SizedBox(
              width: math.max(360, c.maxWidth - 30),
              height: math.max(420, c.maxHeight - 30),
              child: GestureDetector(
                behavior: HitTestBehavior.translucent,
                onPanUpdate: poseMode ? (d) => _dragBone(project, d.delta) : null,
                child: Stack(children: [
                  if (project.background == 'Custom' && project.sceneBackgroundImagePath.isNotEmpty)
                    Positioned.fill(child: Image.file(File(project.sceneBackgroundImagePath), fit: BoxFit.cover)),
                  CustomPaint(painter: _CharacterPainter(project, showBones), size: Size.infinite),
                  if (project.useImageAsBody && project.importedImagePath.isNotEmpty)
                    _ImageBody(project: project),
                ]),
              ),
            ),
          ),
        ),
      );

  void _dragBone(ProjectState p, Offset screenDelta) {
    final bone = p.selectedBone;
    if (p.poseTool == 'rotate') {
      p.setBone(rotation: bone.rotation + screenDelta.dx * .012);
      return;
    }
    if (p.poseTool == 'scale') {
      p.setBone(scale: bone.scale + screenDelta.dy * -.006);
      return;
    }
    final parentRot = p.worldRotationOf(bone.id);
    final cos = math.cos(-parentRot), sin = math.sin(-parentRot);
    final dx = screenDelta.dx / p.camera.zoom;
    final dy = screenDelta.dy / p.camera.zoom;
    final localDx = dx * cos - dy * sin;
    final localDy = dx * sin + dy * cos;
    p.setBone(x: bone.x + localDx, y: bone.y + localDy);
  }
}

_World _worldTransform(Bone b, Map<String, Bone> bones) {
  var x = b.x, y = b.y, r = b.rotation, s = b.scale;
  String? parent = b.parentId;
  var guard = 0;
  while (parent != null && guard++ < 20) {
    final par = bones[parent];
    if (par == null) break;
    final cos = math.cos(par.rotation), sin = math.sin(par.rotation);
    final nx = par.x + x * cos - y * sin;
    final ny = par.y + x * sin + y * cos;
    x = nx;
    y = ny;
    r += par.rotation;
    s *= par.scale;
    parent = par.parentId;
  }
  return _World(x, y, r, s);
}

class _World {
  _World(this.dx, this.dy, this.rotation, this.scale);
  final double dx, dy, rotation, scale;
}

/// Renders the uploaded artwork on the rig. If the user has mapped crop
/// regions to individual parts (Character page), each region is sliced from
/// the source image and drawn following its own bone ÔÇö so arms/legs/head can
/// move independently. Otherwise the whole image follows the torso as one
/// rigid block (basic fallback for a not-yet-segmented upload).
class _ImageBody extends StatefulWidget {
  const _ImageBody({required this.project});
  final ProjectState project;
  @override
  State<_ImageBody> createState() => _ImageBodyState();
}

class _ImageBodyState extends State<_ImageBody> {
  ui.Image? _image;
  String? _loadedPath;

  @override
  void initState() {
    super.initState();
    _maybeLoad();
  }

  @override
  void didUpdateWidget(covariant _ImageBody old) {
    super.didUpdateWidget(old);
    _maybeLoad();
  }

  Future<void> _maybeLoad() async {
    final path = widget.project.importedImagePath;
    if (path.isEmpty || path == _loadedPath) return;
    _loadedPath = path;
    final bytes = await File(path).readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    if (mounted) setState(() => _image = frame.image);
  }

  @override
  Widget build(BuildContext context) {
    final img = _image;
    if (img == null) return const SizedBox.shrink();
    return CustomPaint(painter: _ImagePartsPainter(widget.project, img), size: Size.infinite);
  }
}

class _ImagePartsPainter extends CustomPainter {
  _ImagePartsPainter(this.p, this.image);
  final ProjectState p;
  final ui.Image image;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2 + p.camera.x, size.height / 2 + p.camera.y);
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(p.camera.zoom);
    canvas.rotate(p.camera.rotation);
    final bones = {for (final b in p.bones) b.id: b};
    final iw = image.width.toDouble(), ih = image.height.toDouble();
    final paint = Paint()..filterQuality = FilterQuality.medium;

    void drawPiece(Rect crop, String boneId, double partScale) {
      final bone = bones[boneId];
      if (bone == null) return;
      final w = _worldTransform(bone, bones);
      final src = Rect.fromLTWH(crop.left * iw, crop.top * ih, crop.width * iw, crop.height * ih);
      final destW = src.width * .6 * partScale;
      final destH = src.height * .6 * partScale;
      canvas.save();
      canvas.translate(w.dx, w.dy);
      canvas.rotate(w.rotation);
      final dest = Rect.fromCenter(center: Offset.zero, width: destW * w.scale, height: destH * w.scale);
      canvas.drawImageRect(image, src, dest, paint);
      canvas.restore();
    }

    if (p.hasAnyPartCrop) {
      for (final part in p.parts) {
        if (!part.visible || part.crop == null) continue;
        drawPiece(part.crop!, part.boneId, part.scale);
      }
    } else {
      // Fallback: no parts mapped yet ÔÇö show the whole upload as a single
      // block following the torso, so there is still visible feedback.
      final w = _worldTransform(bones['torso'] ?? bones.values.first, bones);
      final destW = 180.0, destH = 220.0;
      canvas.save();
      canvas.translate(w.dx, w.dy);
      canvas.rotate(w.rotation);
      canvas.drawImageRect(image, Rect.fromLTWH(0, 0, iw, ih), Rect.fromCenter(center: Offset.zero, width: destW * w.scale, height: destH * w.scale), paint);
      canvas.restore();
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _ImagePartsPainter old) => true;
}

class _CharacterPainter extends CustomPainter {
  _CharacterPainter(this.p, this.showBones);
  final ProjectState p;
  final bool showBones;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2 + p.camera.x, size.height / 2 + p.camera.y) + _shakeOffset(p);
    _drawBackground(canvas, size, p.background, p.sceneBackgroundImagePath);
    _drawWeather(canvas, size, p.weather, p.playhead);
    if (p.background == 'Void') {
      final grid = Paint()
        ..color = const Color(0xFF181C27)
        ..strokeWidth = 1;
      for (var x = 0.0; x < size.width; x += 40) canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
      for (var y = 0.0; y < size.height; y += 40) canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(p.camera.zoom);
    canvas.rotate(p.camera.rotation);
    if (showBones && p.onionSkin && p.selectedAnimation.tracks.isNotEmpty) {
      _drawOnionSkeleton(canvas, p, p.playhead - (p.onionBefore / p.playbackFps), true);
      _drawOnionSkeleton(canvas, p, p.playhead + (p.onionAfter / p.playbackFps), false);
    }
    for (final actor in p.actors) {
      final skipBody = actor.id == p.selectedActorId && actor.useImageAsBody && actor.importedImagePath.isNotEmpty;
      canvas.save();
      canvas.translate(actor.offsetX, actor.offsetY);
      canvas.scale(actor.facing, 1);
      _paintActor(canvas, p, actor, showBones && actor.id == p.selectedActorId, skipBody);
      canvas.restore();
    }
    canvas.restore();
  }

  void _drawOnionSkeleton(Canvas canvas, ProjectState p, double time, bool before) {
    final map = {for (final part in p.parts) part.id: part};
    final poses = AnimationRigSync.interpolateAt(
      animation: p.selectedAnimation,
      time: time,
      parts: map,
    );
    final bones = {for (final b in p.bones) b.id: b};
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..color = (before ? const Color(0xFF49A6FF) : const Color(0xFFFFC94A)).withOpacity(.28);

    Offset point(String id) {
      final b = bones[id];
      if (b == null) return Offset.zero;
      final pose = poses[id];
      var x = pose?.x ?? b.x;
      var y = pose?.y ?? b.y;
      var parent = b.parentId;
      var guard = 0;
      while (parent != null && guard++ < 20) {
        final par = bones[parent];
        if (par == null) break;
        final pp = poses[parent];
        final pr = pp?.rotation ?? par.rotation;
        final px = pp?.x ?? par.x;
        final py = pp?.y ?? par.y;
        final cs = math.cos(pr), sn = math.sin(pr);
        final nx = px + x * cs - y * sn;
        final ny = py + x * sn + y * cs;
        x = nx;
        y = ny;
        parent = par.parentId;
      }
      return Offset(x, y);
    }

    for (final b in p.bones) {
      if (b.parentId == null) continue;
      final a = point(b.id);
      final parent = point(b.parentId!);
      canvas.drawLine(parent, a, paint);
      canvas.drawCircle(a, 3.5, paint);
    }
  }

  void _paintActor(Canvas canvas, ProjectState p, SceneActor actor, bool showActorBones, bool skipBody) {
    final bones = {for (final b in actor.bones) b.id: b};
    Offset point(Bone b) {
      var x = b.x, y = b.y;
      String? parent = b.parentId;
      var guard = 0;
      while (parent != null && guard++ < 20) {
        final par = bones[parent];
        if (par == null) break;
        final r = par.rotation;
        final cos = math.cos(r), sin = math.sin(r);
        final nx = par.x + x * cos - y * sin;
        final ny = par.y + x * sin + y * cos;
        x = nx;
        y = ny;
        parent = par.parentId;
      }
      return Offset(x, y);
    }

    void limb(Bone b, double width, Color color) {
      final a = point(b);
      final r = b.rotation + _worldRotation(b, bones);
      final end = a + Offset(math.sin(r) * b.length * b.scale, -math.cos(r) * b.length * b.scale);
      canvas.drawLine(a, end, Paint()..strokeWidth = width..strokeCap = StrokeCap.round..color = color);
    }

    final root = bones['root']!;
    final torso = point(bones['torso']!);
    final head = point(bones['head']!);
    if (!skipBody) {
      _drawOutfit(canvas, torso, head, actor.outfitStyle, actor.clothesColor);
      canvas.drawOval(Rect.fromCenter(center: head, width: 88, height: 98), Paint()..color = actor.skinColor);
      _drawHair(canvas, head, actor.hairStyle, actor.hairColor);
      final dlg = p.activeDialogueFor(actor.id);
      _drawFace(canvas, head, actor, actor.expression, p.playhead, dlg);
      if (dlg != null) _drawSpeechBubble(canvas, head, dlg.text);
      final armLEnd = point(bones['arm_l']!) + Offset(math.sin(bones['arm_l']!.rotation + _worldRotation(bones['arm_l']!, bones)) * bones['arm_l']!.length * bones['arm_l']!.scale, -math.cos(bones['arm_l']!.rotation + _worldRotation(bones['arm_l']!, bones)) * bones['arm_l']!.length * bones['arm_l']!.scale);
      final armREnd = point(bones['arm_r']!) + Offset(math.sin(bones['arm_r']!.rotation + _worldRotation(bones['arm_r']!, bones)) * bones['arm_r']!.length * bones['arm_r']!.scale, -math.cos(bones['arm_r']!.rotation + _worldRotation(bones['arm_r']!, bones)) * bones['arm_r']!.length * bones['arm_r']!.scale);
      _drawAccessories(canvas, head, torso, armLEnd, armREnd, actor);
      final limbColor = Color.lerp(actor.skinColor, Colors.black, .25)!;
      limb(bones['arm_l']!, 24, limbColor);
      limb(bones['arm_r']!, 24, limbColor);
      // Hands and feet are separate rig parts, not decoration. Drawing them
      // from their own bones makes punches, pointing and planted steps read
      // clearly when the animator keys hand_l/hand_r/foot_l/foot_r.
      limb(bones['hand_l']!, 16, limbColor);
      limb(bones['hand_r']!, 16, limbColor);
      limb(bones['leg_l']!, 30, actor.clothesColor);
      limb(bones['leg_r']!, 30, actor.clothesColor);
      limb(bones['foot_l']!, 24, Color.lerp(actor.clothesColor, Colors.black, .35)!);
      limb(bones['foot_r']!, 24, Color.lerp(actor.clothesColor, Colors.black, .35)!);
    }

    if (showActorBones) {
      for (final b in actor.bones) {
        final a = point(b);
        final paint = Paint()
          ..color = b.id == p.selectedBoneId ? const Color(0xFFD4A73B) : const Color(0xFF65B7FF)
          ..strokeWidth = b.id == p.selectedBoneId ? 5 : 3;
        canvas.drawCircle(a, b.id == p.selectedBoneId ? 7 : 4, paint);
        if (b.parentId != null) canvas.drawLine(point(bones[b.parentId]!), a, paint);
      }
      canvas.drawCircle(point(root), 9, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFFD4A73B));
    }
    _drawFx(canvas, torso, head, p);
  }

  /// FX added on the timeline previously only sat in a list with a
  /// timestamp ÔÇö nothing ever appeared on screen. Each one now renders a
  /// real (procedural, no external asset needed) effect while the playhead
  /// is inside its trigger window.
  void _drawFx(Canvas canvas, Offset torso, Offset head, ProjectState p) {
    const window = 0.4;
    for (final e in p.activeFx) {
      final t = (p.playhead - e.time) / window;
      if (t < 0 || t > 1) continue;
      final fade = (1 - t).clamp(0, 1).toDouble();
      switch (e.name) {
        case 'Impact':
          // Anime-style hit: a hard white flash on the first frames of the
          // window (not just a growing ring) ÔÇö the classic Naruto/DBS "big
          // hit" beat ÔÇö fading out fast.
          if (t < .18) canvas.drawRect(Rect.fromLTWH(-2000, -2000, 4000, 4000), Paint()..color = Colors.white.withOpacity((1 - t / .18) * .85));
          canvas.drawCircle(torso, 20 + t * 70, Paint()..color = Colors.white.withOpacity(fade * .8)..style = PaintingStyle.stroke..strokeWidth = 6 * fade + 1);
          canvas.drawCircle(torso, 8 + t * 30, Paint()..color = const Color(0xFFFFD34D).withOpacity(fade * .6));
          break;
        case 'Dust':
          for (var i = 0; i < 5; i++) {
            final a = i * (math.pi * 2 / 5);
            final r = 10 + t * 34;
            canvas.drawCircle(torso.translate(math.cos(a) * r, 70 + math.sin(a) * 8), 5 * fade + 1, Paint()..color = const Color(0xFFB9A67E).withOpacity(fade * .5));
          }
          break;
        case 'Speed Lines':
          for (var i = 0; i < 8; i++) {
            final a = i * (math.pi * 2 / 8);
            final inner = torso + Offset(math.cos(a), math.sin(a)) * (30 + t * 10);
            final outer = torso + Offset(math.cos(a), math.sin(a)) * (30 + t * 90);
            canvas.drawLine(inner, outer, Paint()..color = Colors.white.withOpacity(fade * .55)..strokeWidth = 2);
          }
          break;
        case 'Energy Burst':
          for (var i = 1; i <= 3; i++) {
            canvas.drawCircle(torso, 18 * i + t * 26, Paint()..color = const Color(0xFF6FC7FF).withOpacity(fade * .18)..style = PaintingStyle.stroke..strokeWidth = 3);
          }
          break;
        case 'Smoke':
          for (var i = 0; i < 3; i++) {
            canvas.drawCircle(head.translate((i - 1) * 14.0, -50 - t * 40), 12 + t * 10, Paint()..color = Colors.white.withOpacity(fade * .25));
          }
          break;
        case 'Spark':
          for (var i = 0; i < 6; i++) {
            final a = i * (math.pi * 2 / 6) + t * 2;
            final p1 = torso + Offset(math.cos(a), math.sin(a)) * (10 + t * 40);
            canvas.drawLine(torso, p1, Paint()..color = const Color(0xFFFFE97A).withOpacity(fade)..strokeWidth = 2);
          }
          break;
        case 'Camera Shake':
          // Rendered as a screen-space jitter applied to the whole scene ÔÇö
          // see the translate offset added before this canvas.save() block.
          break;
      }
    }
  }

  /// Every expression actually changes the face (brows, eye shape, mouth
  /// curve) instead of only swapping a label ÔÇö previously only "Terrifying"
  /// did anything visible (red eyes), the rest were cosmetic no-ops.
  void _drawFace(Canvas canvas, Offset head, SceneActor actor, String expression, double timeline, DialogueCue? dialogue) {
    double browAngle = 0, browLift = 0, mouthCurve = 0, eyeScale = 1;
    var mouthOpen = false;
    var mouthWidth = 20.0;
    var mouthHeight = 14.0;
    var asymmetric = false;
    switch (expression) {
      case 'Happy':
        browLift = -3; mouthCurve = 11; eyeScale = .82;
        break;
      case 'Angry':
        browAngle = .35; browLift = 4; mouthCurve = -5; eyeScale = .78;
        break;
      case 'Sad':
        browAngle = -.3; browLift = -1; mouthCurve = -9; eyeScale = .88;
        break;
      case 'Surprised':
        browLift = -8; mouthOpen = true; eyeScale = 1.3;
        break;
      case 'Terrifying':
        browAngle = .45; browLift = 3; mouthOpen = true; eyeScale = 1.15;
        break;
      case 'Determined':
        browAngle = .22; browLift = 1; mouthCurve = -1; eyeScale = .84;
        break;
      case 'Smirk':
        asymmetric = true; mouthCurve = 7; eyeScale = .9; browLift = -1;
        break;
      default:
        break; // Neutral: all defaults
    }
    // Speech visemes can override the expression while a line is spoken.
    // A = open jaw, O = rounded lips, B = closed lips.
    if (dialogue != null) {
      // Auto-cycle visemes while a dialogue line is active — deterministic
      // (driven by timeline, not Random()) so exported frames stay
      // consistent, not real phoneme timing since there's no audio/TTS
      // analysis here, just a readable "talking" flap.
      final cyclePos = ((timeline - dialogue.time) / .12).floor() % 3;
      final shape = ['A', 'B', 'O'][cyclePos];
      if (shape == 'A') { mouthOpen = true; mouthWidth = 22; mouthHeight = 20; }
      if (shape == 'O') { mouthOpen = true; mouthWidth = 12; mouthHeight = 19; }
      if (shape == 'B') { mouthOpen = true; mouthWidth = 24; mouthHeight = 5; }
    } else {
      switch (actor.mouthShape) {
        case 'A':
          mouthOpen = true; mouthWidth = 22; mouthHeight = 20;
          break;
        case 'O':
          mouthOpen = true; mouthWidth = 12; mouthHeight = 19;
          break;
        case 'B':
          mouthOpen = true; mouthWidth = 24; mouthHeight = 5;
          break;
      }
    }

    final browPaint = Paint()
      ..color = actor.hairColor
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    // Two short deterministic blinks every few seconds add life without
    // Random() flicker during repaint or affecting exported frames.
    final blinkPhase = timeline % 3.6;
    final blinking = blinkPhase > 3.15 && blinkPhase < 3.30;
    for (final side in [-1, 1]) {
      final cx = head.dx + side * 17;
      final cy = head.dy - 20 + browLift;
      canvas.save();
      canvas.translate(cx, cy);
      canvas.rotate(side * browAngle);
      canvas.drawLine(const Offset(-9, 0), const Offset(9, 0), browPaint);
      canvas.restore();
    }

    final eyeWhite = Paint()..color = Colors.white;
    final eyeColor = Paint()..color = expression == 'Terrifying' ? const Color(0xFFFF3030) : actor.eyeColor;
    final lidPaint = Paint()..color = actor.skinColor;
    for (final side in [-1, 1]) {
      final ecx = head.dx + side * 17;
      final c = Offset(ecx, head.dy);
      final pupil = c.translate(actor.eyeLookX * 2.5, actor.eyeLookY * 2.5);
      if (blinking) {
        canvas.drawLine(c.translate(-8, 0), c.translate(8, 0), Paint()..color = actor.hairColor..strokeWidth = 2.5..strokeCap = StrokeCap.round);
        continue;
      }
      switch (actor.eyeShape) {
        case 'Sharp':
          final path = Path()
            ..moveTo(c.dx - 9 * eyeScale, c.dy)
            ..quadraticBezierTo(c.dx, c.dy - 5 * eyeScale, c.dx + 9 * eyeScale, c.dy - 2 * eyeScale)
            ..quadraticBezierTo(c.dx, c.dy + 4 * eyeScale, c.dx - 9 * eyeScale, c.dy);
          canvas.drawPath(path, eyeWhite);
          canvas.drawCircle(pupil.translate(1.0 * side, 0), 3 * eyeScale, eyeColor);
          break;
        case 'Sleepy':
          canvas.drawOval(Rect.fromCenter(center: c, width: 14 * eyeScale, height: 6 * eyeScale), eyeWhite);
          canvas.drawCircle(pupil, 3 * eyeScale, eyeColor);
          canvas.drawRect(Rect.fromLTWH(c.dx - 8 * eyeScale, c.dy - 6 * eyeScale, 16 * eyeScale, 4 * eyeScale), lidPaint);
          break;
        case 'Wide':
          canvas.drawCircle(c, 8 * eyeScale, eyeWhite);
          canvas.drawCircle(pupil, 4.2 * eyeScale, eyeColor);
          canvas.drawCircle(pupil.translate(-1.5, -1.5), 1.4 * eyeScale, Paint()..color = Colors.white);
          break;
        case 'Cat':
          final path = Path()
            ..moveTo(c.dx - 8 * eyeScale, c.dy + 3 * eyeScale)
            ..quadraticBezierTo(c.dx - 2 * eyeScale, c.dy - 6 * eyeScale, c.dx + 9 * eyeScale, c.dy - 3 * eyeScale)
            ..quadraticBezierTo(c.dx, c.dy + 5 * eyeScale, c.dx - 8 * eyeScale, c.dy + 3 * eyeScale);
          canvas.drawPath(path, eyeWhite);
          canvas.drawOval(Rect.fromCenter(center: pupil, width: 3 * eyeScale, height: 6 * eyeScale), eyeColor);
          break;
        default: // Round
          canvas.drawCircle(c, 6 * eyeScale, eyeWhite);
          canvas.drawCircle(pupil, 3 * eyeScale, eyeColor);
      }
    }

    final mouthPaint = Paint()
      ..color = const Color(0xFF7C3030)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final mCenter = head.translate(asymmetric ? 3 : 0, 24);
    if (mouthOpen) {
      canvas.drawOval(Rect.fromCenter(center: mCenter, width: mouthWidth, height: mouthHeight), Paint()..color = const Color(0xFF3A1414));
      canvas.drawOval(Rect.fromCenter(center: mCenter, width: mouthWidth, height: mouthHeight), mouthPaint);
    } else {
      final path = Path()
        ..moveTo(mCenter.dx - 9, mCenter.dy)
        ..quadraticBezierTo(mCenter.dx, mCenter.dy - mouthCurve, mCenter.dx + 9, mCenter.dy - (asymmetric ? mouthCurve * 1.6 : 0));
      canvas.drawPath(path, mouthPaint);
    }
  }


  void _drawHair(Canvas canvas, Offset head, String style, Color color) {
    final hair = Paint()..color = color;
    switch (style) {
      case 'Long':
        canvas.drawArc(Rect.fromCenter(center: head.translate(0, -6), width: 100, height: 96), math.pi, math.pi, true, hair);
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: head.translate(-40, 40), width: 18, height: 90), const Radius.circular(9)), hair);
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: head.translate(40, 40), width: 18, height: 90), const Radius.circular(9)), hair);
        break;
      case 'Spike':
        canvas.drawArc(Rect.fromCenter(center: head.translate(0, -8), width: 98, height: 90), math.pi, math.pi, true, hair);
        for (var i = -2; i <= 2; i++) {
          final base = head.translate(i * 18.0, -44);
          final path = Path()
            ..moveTo(base.dx - 9, base.dy + 10)
            ..lineTo(base.dx, base.dy - 26)
            ..lineTo(base.dx + 9, base.dy + 10)
            ..close();
          canvas.drawPath(path, hair);
        }
        break;
      case 'Queue':
        canvas.drawArc(Rect.fromCenter(center: head.translate(0, -8), width: 98, height: 90), math.pi, math.pi, true, hair);
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: head.translate(0, 60), width: 14, height: 80), const Radius.circular(7)), hair);
        break;
      case 'Chauve':
        break;
      case 'Frange':
        canvas.drawArc(Rect.fromCenter(center: head.translate(0, -6), width: 98, height: 94), math.pi, math.pi, true, hair);
        canvas.drawRect(Rect.fromLTWH(head.dx - 30, head.dy - 34, 60, 16), hair);
        break;
      case 'Afro':
        canvas.drawCircle(head.translate(0, -18), 52, hair);
        break;
      case 'Mohawk':
        final path = Path()
          ..moveTo(head.dx - 8, head.dy - 30)
          ..lineTo(head.dx - 12, head.dy - 70)
          ..lineTo(head.dx + 12, head.dy - 70)
          ..lineTo(head.dx + 8, head.dy - 30)
          ..close();
        canvas.drawPath(path, hair);
        break;
      default:
        canvas.drawArc(Rect.fromCenter(center: head.translate(0, -8), width: 98, height: 90), math.pi, math.pi, true, hair);
    }
  }

  /// Generic silhouette shapes for the torso ÔÇö original outlines, not based
  /// on any specific franchise design.
  void _drawOutfit(Canvas canvas, Offset torso, Offset head, String style, Color color) {
    final paint = Paint()..color = color;
    switch (style) {
      case 'Hoodie':
        canvas.drawOval(Rect.fromCenter(center: torso, width: 114, height: 152), paint);
        final hood = Path()
          ..moveTo(head.dx - 30, head.dy - 6)
          ..quadraticBezierTo(head.dx, head.dy - 60, head.dx + 30, head.dy - 6)
          ..quadraticBezierTo(head.dx, head.dy + 4, head.dx - 30, head.dy - 6);
        canvas.drawPath(hood, paint..color = color.withOpacity(.9));
        break;
      case 'Jacket':
        canvas.drawOval(Rect.fromCenter(center: torso, width: 118, height: 150), paint);
        canvas.drawLine(torso.translate(-6, -60), torso.translate(-18, 30), Paint()..color = Colors.black26..strokeWidth = 3);
        canvas.drawLine(torso.translate(6, -60), torso.translate(18, 30), Paint()..color = Colors.black26..strokeWidth = 3);
        break;
      case 'Robe':
        final path = Path()
          ..moveTo(torso.dx - 44, torso.dy - 66)
          ..lineTo(torso.dx + 44, torso.dy - 66)
          ..lineTo(torso.dx + 70, torso.dy + 90)
          ..lineTo(torso.dx - 70, torso.dy + 90)
          ..close();
        canvas.drawPath(path, paint);
        break;
      case 'Dress':
        canvas.drawOval(Rect.fromCenter(center: torso.translate(0, -20), width: 90, height: 90), paint);
        final skirt = Path()
          ..moveTo(torso.dx - 30, torso.dy + 10)
          ..lineTo(torso.dx + 30, torso.dy + 10)
          ..lineTo(torso.dx + 62, torso.dy + 95)
          ..lineTo(torso.dx - 62, torso.dy + 95)
          ..close();
        canvas.drawPath(skirt, paint);
        break;
      case 'Armor':
        canvas.drawOval(Rect.fromCenter(center: torso, width: 116, height: 148), paint);
        final plate = Paint()..color = Color.lerp(color, Colors.white, .25)!;
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: torso.translate(0, -30), width: 70, height: 26), const Radius.circular(6)), plate);
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: torso.translate(0, 10), width: 74, height: 26), const Radius.circular(6)), plate);
        break;
      case 'Cape':
        canvas.drawOval(Rect.fromCenter(center: torso, width: 96, height: 140), paint);
        final cape = Path()
          ..moveTo(torso.dx - 30, torso.dy - 60)
          ..lineTo(torso.dx + 30, torso.dy - 60)
          ..lineTo(torso.dx + 48, torso.dy + 120)
          ..lineTo(torso.dx - 48, torso.dy + 120)
          ..close();
        canvas.drawPath(cape, Paint()..color = Color.lerp(color, Colors.black, .3)!);
        break;
      case 'Suit':
        canvas.drawOval(Rect.fromCenter(center: torso, width: 104, height: 148), paint);
        canvas.drawRect(Rect.fromCenter(center: torso.translate(0, -30), width: 14, height: 60), Paint()..color = Colors.white);
        final lapel = Paint()..color = Color.lerp(color, Colors.black, .35)!;
        canvas.drawLine(torso.translate(-4, -60), torso.translate(-22, -10), lapel..strokeWidth = 8);
        canvas.drawLine(torso.translate(4, -60), torso.translate(22, -10), Paint()..color = Color.lerp(color, Colors.black, .35)!..strokeWidth = 8);
        break;
      case 'Tactical Vest':
        canvas.drawOval(Rect.fromCenter(center: torso, width: 108, height: 146), paint);
        final strap = Paint()..color = Color.lerp(color, Colors.black, .4)!;
        for (final dx in [-24.0, 0.0, 24.0]) {
          canvas.drawRect(Rect.fromCenter(center: torso.translate(dx, 0), width: 10, height: 110), strap);
        }
        canvas.drawRect(Rect.fromCenter(center: torso.translate(0, -50), width: 70, height: 10), strap);
        break;
      case 'Battle Cloak':
        canvas.drawOval(Rect.fromCenter(center: torso, width: 100, height: 142), paint);
        final cloak = Path()
          ..moveTo(torso.dx - 26, torso.dy - 64)
          ..lineTo(torso.dx + 26, torso.dy - 64)
          ..lineTo(torso.dx + 60, torso.dy + 130)
          ..quadraticBezierTo(torso.dx, torso.dy + 150, torso.dx - 60, torso.dy + 130)
          ..close();
        canvas.drawPath(cloak, Paint()..color = Color.lerp(color, Colors.black, .25)!);
        canvas.drawCircle(torso.translate(0, -58), 6, Paint()..color = const Color(0xFFC9A227));
        break;
      default: // Tank
        canvas.drawOval(Rect.fromCenter(center: torso, width: 92, height: 140), paint);
    }
  }

  /// Small procedural extras ÔÇö none tied to any specific character design.
  /// Speech bubble above the speaking actor's head — doubles as an on-screen
  /// caption once exported, useful for TikTok/YouTube-style clips.
  void _drawSpeechBubble(Canvas canvas, Offset head, String text) {
    final span = TextPainter(
      text: TextSpan(text: text, style: const TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.w600)),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    )..layout(maxWidth: 160);
    final w = span.width + 20, h = span.height + 16;
    final center = head.translate(0, -84 - h / 2);
    final rect = RRect.fromRectAndRadius(Rect.fromCenter(center: center, width: w, height: h), const Radius.circular(10));
    final bubble = Paint()..color = Colors.white.withOpacity(.95);
    canvas.drawRRect(rect, bubble);
    canvas.drawRRect(rect, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = Colors.black26);
    final tail = Path()
      ..moveTo(head.dx - 8, center.dy + h / 2)
      ..lineTo(head.dx + 8, center.dy + h / 2)
      ..lineTo(head.dx, center.dy + h / 2 + 12)
      ..close();
    canvas.drawPath(tail, bubble);
    span.paint(canvas, Offset(center.dx - span.width / 2, center.dy - span.height / 2));
  }

  void _drawAccessories(Canvas canvas, Offset head, Offset torso, Offset handL, Offset handR, SceneActor actor) {
    if (actor.accHeadband) {
      canvas.drawRect(Rect.fromCenter(center: head.translate(0, -26), width: 80, height: 12), Paint()..color = const Color(0xFF2C3448));
      canvas.drawCircle(head.translate(0, -26), 4, Paint()..color = const Color(0xFFB0B8C8));
    }
    if (actor.accGlasses) {
      final ring = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..color = const Color(0xFF1A1A1A);
      canvas.drawCircle(head.translate(-17, 0), 10, ring);
      canvas.drawCircle(head.translate(17, 0), 10, ring);
      canvas.drawLine(head.translate(-7, 0), head.translate(7, 0), ring);
    }
    if (actor.accScarf) {
      canvas.drawOval(Rect.fromCenter(center: head.translate(0, 46), width: 64, height: 26), Paint()..color = const Color(0xFF7C2431));
      canvas.drawRect(Rect.fromCenter(center: head.translate(14, 74), width: 16, height: 40), Paint()..color = const Color(0xFF7C2431));
    }
    if (actor.accHat) {
      final hatColor = Paint()..color = Color.lerp(actor.clothesColor, Colors.black, .2)!;
      canvas.drawOval(Rect.fromCenter(center: head.translate(0, -46), width: 76, height: 22), hatColor);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: head.translate(0, -60), width: 54, height: 30), const Radius.circular(8)), hatColor);
    }
    if (actor.accGloves) {
      final gloveColor = Paint()..color = Color.lerp(actor.clothesColor, Colors.black, .3)!;
      canvas.drawCircle(handL, 11, gloveColor);
      canvas.drawCircle(handR, 11, gloveColor);
    }
    if (actor.accBelt) {
      canvas.drawRect(Rect.fromCenter(center: torso.translate(0, 52), width: 96, height: 14), Paint()..color = const Color(0xFF2A1E14));
      canvas.drawRect(Rect.fromCenter(center: torso.translate(0, 52), width: 16, height: 12), Paint()..color = const Color(0xFFC9A227));
    }
  }

  double _worldRotation(Bone b, Map<String, Bone> bones) {
    var r = b.rotation;
    var parent = b.parentId;
    var guard = 0;
    while (parent != null && guard++ < 20) {
      final x = bones[parent];
      if (x == null) break;
      r += x.rotation;
      parent = x.parentId;
    }
    return r;
  }

  @override
  bool shouldRepaint(covariant _CharacterPainter old) => true;
}

/// Deterministic (not random) jitter so repaints are stable frame to frame ÔÇö
/// driven by playhead time, not Random(), otherwise the shake would flicker
/// inconsistently between rebuilds instead of reading as a camera shake.
/// Simple generic flat-shape backdrops (gradients + a few silhouettes) ÔÇö
/// original, not depicting any real or copyrighted place, just enough
/// atmosphere so the viewport isn't always a plain void.
void _drawWeather(Canvas canvas, Size size, String weather, double time) {
  if (weather == 'Clear') return;
  final paint = Paint()..strokeWidth = 1.5;
  for (var i = 0; i < 80; i++) {
    final seed = i * 17.0;
    final x = (seed * 37 + time * 120) % size.width;
    final y = (seed * 53 + time * 280) % size.height;
    if (weather == 'Rain') {
      paint.color = Colors.white.withOpacity(.35);
      canvas.drawLine(Offset(x, y), Offset(x - 4, y + 14), paint);
    } else {
      paint.color = Colors.white.withOpacity(.55);
      canvas.drawCircle(Offset(x, y), 2, paint);
    }
  }
}

void _drawBackground(Canvas canvas, Size size, String style, String customPath) {
  final rect = Offset.zero & size;
  switch (style) {
    case 'Forest':
      canvas.drawRect(rect, Paint()..shader = ui.Gradient.linear(Offset(0, 0), Offset(0, size.height), [const Color(0xFF1B3B2E), const Color(0xFF0E1F17)]));
      final tree = Paint()..color = const Color(0xFF0A1712);
      for (var i = 0; i < 6; i++) {
        final x = size.width * (i + .5) / 6;
        final h = 90 + (i.isEven ? 30 : 0);
        final path = Path()..moveTo(x, size.height - 40 - h)..lineTo(x - 34, size.height - 40)..lineTo(x + 34, size.height - 40)..close();
        canvas.drawPath(path, tree);
      }
      break;
    case 'Rooftop City':
    case 'Rainy City':
      canvas.drawRect(rect, Paint()..shader = ui.Gradient.linear(Offset(0, 0), Offset(0, size.height), style == 'Rainy City' ? [const Color(0xFF1A2233), const Color(0xFF2A3348)] : [const Color(0xFF10131F), const Color(0xFF262B45)]));
      final b = Paint()..color = const Color(0xFF0B0E17);
      final win = Paint()..color = (style == 'Rainy City' ? const Color(0xFF8EB4FF) : const Color(0xFFFFD98A)).withOpacity(.45);
      for (var i = 0; i < 7; i++) {
        final w = 40.0 + (i % 3) * 14;
        final x = i * (size.width / 7);
        final h = 120.0 + (i % 4) * 40;
        canvas.drawRect(Rect.fromLTWH(x, size.height - h, w, h), b);
        for (var wy = size.height - h + 12; wy < size.height - 12; wy += 18) {
          for (var wx = x + 6; wx < x + w - 6; wx += 14) canvas.drawRect(Rect.fromLTWH(wx, wy, 6, 8), win);
        }
      }
      if (style == 'Rainy City') canvas.drawRect(Rect.fromLTWH(0, size.height - 36, size.width, 36), Paint()..color = const Color(0xFF1E2838).withOpacity(.7));
      break;
    case 'Neon Street':
      canvas.drawRect(rect, Paint()..shader = ui.Gradient.linear(Offset(0, 0), Offset(0, size.height), [const Color(0xFF120818), const Color(0xFF2A1038)]));
      final neon = [const Color(0xFFFF4FD8), const Color(0xFF4FD8FF), const Color(0xFF9DFF4F)];
      for (var i = 0; i < 5; i++) {
        final x = size.width * (i + .3) / 5;
        canvas.drawRect(Rect.fromLTWH(x, size.height * .35, 8, size.height * .65), Paint()..color = neon[i % 3].withOpacity(.35));
        canvas.drawCircle(Offset(x + 4, size.height * .3), 18, Paint()..color = neon[i % 3].withOpacity(.5));
      }
      break;
    case 'Dojo':
      canvas.drawRect(rect, Paint()..shader = ui.Gradient.linear(Offset(0, 0), Offset(0, size.height), [const Color(0xFF2B1E16), const Color(0xFF16100B)]));
      final floor = Paint()..color = const Color(0xFF120C08);
      for (var y = size.height * .6; y < size.height; y += 22) canvas.drawLine(Offset(0, y), Offset(size.width, y), floor..strokeWidth = 2);
      canvas.drawCircle(Offset(size.width / 2, size.height * .22), 46, Paint()..color = const Color(0xFFFFD98A).withOpacity(.18));
      break;
    case 'Sunset Sky':
      canvas.drawRect(rect, Paint()..shader = ui.Gradient.linear(Offset(0, 0), Offset(0, size.height), [const Color(0xFFFF8A4D), const Color(0xFF3A2151)]));
      canvas.drawCircle(Offset(size.width / 2, size.height * .42), 60, Paint()..color = const Color(0xFFFFE1A8).withOpacity(.85));
      break;
    case 'Custom':
      break; // drawn as a separate Image.file widget layer beneath this canvas — see ShinraViewport
    default: // Void
      canvas.drawRect(rect, Paint()..color = const Color(0xFF090B11));
  }
}

Offset _shakeOffset(ProjectState p) {  const window = 0.4;
  for (final e in p.activeFx) {
    if (e.name != 'Camera Shake') continue;
    final t = (p.playhead - e.time) / window;
    if (t < 0 || t > 1) continue;
    final amp = (1 - t) * 10;
    final phase = p.playhead * 90;
    return Offset(math.sin(phase) * amp, math.cos(phase * 1.3) * amp);
  }
  return Offset.zero;
}
